#Mypackage
This library was created as an example on how to publish your own python package .
